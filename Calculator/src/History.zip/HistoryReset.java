package History;


import java.io.PrintWriter;
import java.io.IOException;

class HistoryReset {

	public static void main(String[] args) throws IOException {
		
		PrintWriter reset = new PrintWriter("D:/out.txt");
		
		reset.close();
				
	}

}
